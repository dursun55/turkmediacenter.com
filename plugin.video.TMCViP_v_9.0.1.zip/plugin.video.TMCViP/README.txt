# Simple for Kodi  plugin.video.Turkmediacenter 
Bu eklenti xbmcPlayer den esinlenerek hazirlanmis test amacli free bir video eklentisidir.
This plugin is a test free video plugin inspired by xbmcPlayer den.
daha once kodi icin icerik hazirlamis (Teng - Pcd -XorioN 'a Tesekkurler) ustalarin yaptiklari iceriklerde isik tuttu.
(Teng - Pcd - XorioN - Thanks) has made the ingredients for the code.  
This is a simple yet fully functional example of a video plugin for [Kodi](http://kodi.tv) 
Please read the comments in the plugin code for more details.
An installable .zip can be downloaded from "[Releases](http://turkmediacenter.com/)plugin.video.Turkmediacenter" tab.
>=======>uygulamanin guncel surumlerini <==> www.turkmediacenter.com <==> indirebilirsiniz.<=======<
**Note**: the purpose of this example plugin is to show you how to organize and play your media content in Kodi.
uygulamanin yuklendigi sunucular free oldugundan kapanmamasi icin baska forumlarda lutfen paylasmayiniz.
Do not share it in other forums for closing since the servers on which the application is installed are free.
uygulamanin icerigi  yotube ve vk.com gibi sitelerden alinan embed kodu ile calismaktadir.
The application is working with embed code from yotube and vk.com sites.
Sonuc olarak portal kendi bunyesinde herhangi bir video barindirmamakta olup video barindiran sitelerden alinan kod ile calismaktadir.
As a result, the portal itself has no video repository on it and works with the code that is received from the video library sites.
bu sitelerdeki icerikler cesitli nedenlerle silindiginde uygulamadada calismaz.
These contents do not work in practice when the contents are deleted for various reasons.
bu uygulama free olarak paylasilmaktadir.kesinlikle bagis veya baska nedenle odeme yapmayiniz.
This application is shared free of charge.
uygulamayi webcenter adina hazirlayan isimsiz kahramana sonsuz Tesekkurler.
Anonymous hero who prepares the application webcenter name eternal Thank you.
>====>uygulamanin guncel surumlerini <==> www.turkmediacenter.com <==> indirebilirsiniz.<====<
>=======>Webcenter - SilaPlayer'de  iyi seyirler diler.>=======> TURK MEDIA CENTER <======<
