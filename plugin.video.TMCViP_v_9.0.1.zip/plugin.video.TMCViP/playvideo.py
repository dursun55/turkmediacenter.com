# -*- coding: utf-8 -*-
# -*- www.turkmediacenter.com -*-
# -*-Webcenter@SilaPlayer©2020 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,random,urlresolver,cookielib
import json, base64,requests
from urlparse import parse_qs
from urllib import urlencode
from xml.dom import minidom
import sys
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
dialog = xbmcgui.Dialog()	

  
def CATEGORIES():
	
        addDir('Turk_Media_Center_','http://tmcwebcenter.com/tmc4.php',1,'http://i.hizliresim.com/l3XX9r.png')	                   			
        addDir( '_!_Web_Vip_!_','http://tmcwebcenter.com/vip1.php',7,'http://i.hizliresim.com/77RqrW.png')
        addDir('_=_info:Free uygulamadir._=_','INFO',5,'http://i.hizliresim.com/5D9Oyd.png')
        addDir('_=_Webcenter@SilaPlayer©2020_=_','INFO',5,'http://i.hizliresim.com/5D9Oyd.png')
        addDir('_=_www.turkmediacenter.com_=_','INFO',5,'http://i.hizliresim.com/77RqP5.png') 
        
		
def Pass():
        keyboard = xbmc.Keyboard("", '[COLOR FF00FFFF]18 yasindan kucuklere burasi yasaktir.[/COLOR]', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://tmcwebcenter.com/vip1.'+query)
	url=url.replace('1234',"php")
        url=url.encode('utf-8')
        Adult(url)
		
def RECENT(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<channel>\s*<title><!\[CDATA\[(.*?)].*?<\/title>\s*<logo_30x30><!\[CDATA\[(.*?)].*?<\/logo_30x30>\s*.*\s*.*\s*<playlist_url><!\[CDATA\[(.*?)].*?<\/playlist_url>\s*<\/channel>').findall(link)
        for name,thumbnail,url in match:
	        url=url.encode('utf-8')
	        if "search" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,14,thumbnail)
	        if "FavoriListe" in name:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,15,thumbnail)
	        if "canlitv.vin/" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,8,thumbnail)					
	        if "tmcwebcenter" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,1,thumbnail)                
                if "canlidizi" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,3,thumbnail)
                if "googleapis.com" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,17,thumbnail)
                if "kanald.com" in url:
                    addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,18,thumbnail)					

        getlink=re.compile('<channel>\s*<title><!\[CDATA\[(.*?)].*?<\/title>\s*<logo_30x30><!\[CDATA\[(.*?)].*?<\/logo_30x30>\s*.*\s*.*\s*<stream_url><!\[CDATA\[(.*?)].*?<').findall(link)				
        for name,thumbnail,url in getlink: 
		url=url.encode('utf-8')	
	        if "mail.ru" in url:
                    addDir('=>''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,16,thumbnail)
	        if not "mail.ru" in url:
                    addDir('=>''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,2,thumbnail)					

def Adult(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<channel>\s*<title><!\[CDATA\[(.*?)].*?<\/title>\s*<logo_30x30><!\[CDATA\[(.*?)].*?<\/logo_30x30>\s*.*\s*.*\s*<playlist_url><!\[CDATA\[(.*?)].*?<').findall(link)
        for name,thumbnail,url in match:
		url=url.encode('utf-8')
                addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,1,thumbnail)

def SearchDizi(url):
        keyboard = xbmc.Keyboard("", '[COLOR FF00FFFF]Search[/COLOR]', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = url + '?s=' + query
            kategoriicrerik(url)
			
def SearchMailRu(url):
        keyboard = xbmc.Keyboard("", '[COLOR FF00FFFF]Search[/COLOR]', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = url + query
            PageMailRu(url)

def SearchKanald(url):
        keyboard = xbmc.Keyboard("", '[COLOR FF00FFFF]Search[/COLOR]', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = url + 'arama?q=' + query
            kanaldkategoriicrerik(url)
			
def SearchPlaylistMailRu(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('"Title": "([^"]+)".*?\s*"UrlHtml": "(.*?)"').findall(link)
        for name, url in match:
           #url=url.replace('/mail/',"http://my.mail.ru/mail/")
           addDir('=>''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,16,'')
		   
def PageMailRu(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('"title": "(.*?)","urlHtml": "(.*?)"').findall(link)
        for name, url in match:
           url=url.replace('/mail/',"https://my.mail.ru/mail/")
           addDir('=>''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,16,'')
		   
def Parsmailru(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('src" href="(.*?)"').findall(link)
        for url in match:
                query = url.split("/")
                url = 'http://my.mail.ru/+/video/meta/'+ query[7]
                Play(url,name)
				
def kategoriler(url):
        addDir( '***!_Search_!***','https://www.canlidizihd8.net/',12,'https://i.hizliresim.com/Z9yZNg.png')
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('cat-item-\d+"><a href="([^"]+)"[^>]+>([^<]+)<').findall(link)
        for url, name in match:
                addDir('=>'+name,url,4,'') 
def kategoriicrerik(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a class="kutu-icerik-title indexbaslik" href="(.*?)" title="(.*?)"').findall(link)
        for url, name in match:
                addDir('=>'+name, url,6,'')			
def Modulplay(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<p>.*?<iframe.*?src="(.*?)"').findall(link)
        for url in match:
                url=url.replace('#038;','')
                if 'dailymotion' in url:
                        query = url.split("?")
                        url = query[0]                       
                addDir('Play''[COLOR FFFFFFFF]''[/COLOR]',url,2,'')
        getlink=re.compile('<a href="(.*?)"><span>(.*?Parça)<\/span>').findall(link)
        for url,name in getlink:
                url=url.encode('utf-8')
				
                addDir(' ''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,6,'')
				
def tvkategoriler(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
	match=re.compile('<li><a href="(.*?)" title="(.*?)">(.*?)<\/a><\/li>').findall(link)
        for url,name,thumbnail in match:
         addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,9,thumbnail)         
def tvkategoriicrerik(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<a href="(.*?)" title="(.*?)">\s*<div class="kanallarlogo"><img src="(.*?)" alt=".*?"').findall(link)
        for url,name,thumbnail in match:
		addDir('=>''[COLOR FF00FFFF]'+name+'[/COLOR]',url,10,thumbnail)
def tvstreamicrerik(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<iframe.*?src="(.*?)"').findall(link)
        for url in match:
		url=url.encode('utf-8')
		tvstream(url)
def tvstream(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile("file: '(.*?)'").findall(link)
        for url in match:
		url=url.encode('utf-8')
		Play(url,name)
def Youplaylist(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('title": "([^"]+)".*\s*.*\s*.*\.*\s*.*.*\s*"url": "([^"]+)"').findall(link)
        for name, url in match:
                query = url.split("/")
                url = 'http://www.youtube.com/watch?v='+query[4] 
                addDir('=>''[COLOR FFFFFFFF]'+name+'[/COLOR]',url,2,'https://i.ytimg.com/vi/'+query[4]+'/hqdefault.jpg')
def kanaldkatogeri(url):
        addDir( '***!_Search_!***','https://www.kanald.com.tr/',22,'https://s.kanald.com.tr/ps/kanald_proxy/assets/img/logo.v2.png?v=7')
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('&#199;',"C").replace('&#231;',"c").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")		
        response.close()
        match=re.compile('<a class="thumbnail thumbnail-featured " href="([^"]+)"><img src=".*?" data-src="([^"]+)" alt="([^"]+)"').findall(link)
        for url, thumbnail, name in match:
                addDir('=>'+name,'https://www.kanald.com.tr/'+url+'/bolumler',19,'http:'+thumbnail)
def kanaldkategoriicrerik(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('&#199;',"C").replace('&#231;',"c").replace('&#246;',"o").replace('&#252;',"u").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")		
        response.close()
        match=re.compile('<div class="col-lg-12"><div class="bg clearfix"><a href="([^"]+)" class="thumbnail".*?src=".*?" data-src="([^"]+)" alt="([^"]+)"').findall(link)		
        for url, thumbnail, name in match:
                #url = 'https://www.kanald.com.tr'+ url		
                addDir('=>'+name,'https://www.kanald.com.tr'+url,20,'http:'+thumbnail)
def kanaldparser(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('"contentid", "([^"]+)"').findall(link)
        for url in match:
                url = 'https://www.kanald.com.tr/actions/content/media/'+ url			
                kanaldparser2(url)
def kanaldparser2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('SecurePath":"(.*?)"').findall(link)
        for url in match:
                query = url.split("?")
                url = query[0]
        url=url.replace('index.m3u8',"1000/prog_index.m3u8")				
        if not "http" in url:		
                Play('https://soledge4.dogannet.tv//'+url,name)
        if "http" in url:	
                Play(url,name)				
def Play(url,name):       
        playList.clear()
        url = str(url).encode('utf-8', 'ignore')
	url=url.encode('utf-8')
        	
        if "hqq." in url:
                url= urlresolver.resolve(url)				
        elif "youtube" in url:
                url= urlresolver.resolve(url)			
        elif "dailymotion" in url:
                url= urlresolver.resolve(url)
        elif "openload.co" in url:
                url= urlresolver.resolve(url)                
        elif "mail.ru/" in url:
                url= Parsmailrulink(url)				
        elif "oynat" in url:
                url= oynaticrerik(url)
        elif "vk.com" in url:
                url= urlresolver.resolve(url)
        elif "ok.ru" in url:
                url= urlresolver.resolve(url)
        elif "oload" in url:
                url= urlresolver.resolve(url)
        elif "docs.google.com" in url:
                url= urlresolver.resolve(url)
        elif "drive.google.com" in url:
                url= urlresolver.resolve(url)	                 
        elif "rapidvideo.com" in url:
                url= urlresolver.resolve(url)	
        elif "vidmoly.to" in url:
                url= urlresolver.resolve(url)	                                    	                       
        elif "vidmoly.me" in url:
                url= VidmolyPlay(url)	                               	                				
        elif ".flv" in url:
                url= urlresolver.resolve(url)                
        elif 'rtmp:'  in url:
                url= url
        elif 'rtsp:'  in url:
                url= url								
        elif  'mms:' in url:
                url= url
        elif '.m3u8' in url:
                url= url
        elif '.mp4/?br=' in url:
                url= url                
        elif url.endswith('.mp4'):
                url= url					
        else:
                url=url
        if url:
                addLink(name,url,'')
                
                listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                listitem.setInfo('video', {'name': name } )
                playList.add(url,listitem=listitem)
                xbmc.Player().play(playList)
				
        else:
                showMessage("Link bulunamadi ya da acilamiyor")

	   
def Parsmailrulink(url):
    try:
        listem=[]
        kalx=[]		
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('url":"(\/\/cdn[^"]+)".*?"key":"([^"]+)"').findall(link)
        url = url+'?ver=0.2.60'		
        result = requests.get(url).content
        cookie = requests.get(url).headers['Set-Cookie']
        u = json.loads(result)['videos']
        h = "|Cookie=%s" % urllib.quote(cookie)

        
        for url, name in match:      
            listem.append('http:'+url+h)
            kalx.append(name)

        dialog = xbmcgui.Dialog()
        secim = dialog.select('Mail.ru Kalite Secin...',kalx)
        
        for i in range(len(kalx)):
          
          if secim == i:
            url=listem[i]
           
            return url
          else:
            pass  
          
    except Exception, e:
       print('**** Mail.ru Hata: %s' % e)

def VidmolyPlay(url):
    try:
        listem=[]
        kalx=[]
        		               
        headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04'}
        req = urllib2.Request(url, None, headers)
        response = urllib2.urlopen(req)
        html = response.read()
        if re.search("type='text/javascript'>(eval\\(function.*?)\\n", html):
          packed = re.findall("type='text/javascript'>(eval\\(function.*?)\\n", html, re.IGNORECASE)[0]
          html = cPacker().unpack(packed)
        for match in re.finditer('"([^"]+(mp4))"', html):
           linko = match.group(1)
        if linko.startswith("//"):
            linko = "http:" + linko
            film_quality.append(match.group(2))
            video_tulpe.append(linko)
        
        for url, name in match:      
            listem.append('http:'+url+h)
            kalx.append(name)

        dialog = xbmcgui.Dialog()
        secim = dialog.select('Vidmoly.me Kalite Secin...',kalx)
        
        for i in range(len(kalx)):
          
          if secim == i:
            url=listem[i]
           
            return url
          else:
            pass  
          
    except Exception, e:
       print('**** Vidmoly.me Hata: %s' % e)       
	   
def oynaticrerik(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('file":"(.*?)"').findall(link)
        listem=[]
        kalx=[]
        if match:
                listem.append(match[1])
                kalx.append('SD Kalite')         
        if match:
                listem.append(match[0])
                kalx.append('HD Kalite')
        dialog = xbmcgui.Dialog()
        secim = dialog.select('Kalite Secin...',kalx)
        for i in range(len(kalx)):
                if secim == i:
                        url=listem[i]
	return url	   
def INFO(url):
  try:
        CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "this plugin based on XbmcTR!","It is free","iyi seyirler.SilaPlayer©2020")
  except:
        
        pass 

def YoutubePlay(url):	   
       yt_id = url.replace("http://www.youtube.com/embed/","").replace("http://www.youtube.com/watch?v=","").replace("https://www.youtube.com/embed/","").replace("https://www.youtube.com/watch?v=","")
       url='plugin://plugin.video.youtube/?action=play_video&videoid=' + yt_id 
       return url
               
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()       
elif mode==1:
        print ""+url
        RECENT(url)
elif mode==3:
        print ""+url
        kategoriler(url)      
elif mode==4:
        print ""+url
        kategoriicrerik(url)
elif mode==6:         
        Modulplay(url)        
elif mode==5:
        print ""+url
        INFO(url)
elif mode==7:
        print ""+url
        Pass()        		
elif mode==8:
        print ""+url
        tvkategoriler(url)      
elif mode==9:
        print ""+url
        tvkategoriicrerik(url)
elif mode==10:
        print ""+url
        tvstreamicrerik(url)
elif mode==11:
        print ""+url
        tvstream(url)
elif mode==12:
        print ""+url
        SearchDizi(url)
elif mode==22:
        print ""+url
        SearchKanald(url)		
elif mode==13:
        print ""+url
        PageMailRu(url)
elif mode==14:
        print ""+url
        SearchMailRu(url)
elif mode==15:
        print ""+url
        SearchPlaylistMailRu(url)
elif mode==16:
        print ""+url
        Parsmailru(url)
elif mode==17:
        print ""+url
        Youplaylist(url)
elif mode==18:
        print ""+url
        kanaldkatogeri(url)
elif mode==19:
        print ""+url
        kanaldkategoriicrerik(url)
elif mode==20:
        print ""+url
        kanaldparser(url)
elif mode==21:
        print ""+url
        kanaldparser2(url)		
elif mode==2:         
        Play(url,name) 		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

